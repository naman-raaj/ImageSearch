import React, { useEffect, useRef, useState } from "react";

interface AddCaptionPageProps {
  imageUrl: string;
}

interface CanvasElement {
  id: number;
  type: "text" | "rectangle" | "circle" | "triangle" | "polygon" | "image";
  x: number;
  y: number;
  width?: number;
  height?: number;
  radius?: number;
  text?: string;
  color?: string;
  points?: { x: number; y: number }[];
  isDragging?: boolean;
  offsetX?: number;
  offsetY?: number;
}

const AddCaptionPage: React.FC<AddCaptionPageProps> = ({ imageUrl }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null);
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>([]);
  const [draggingElement, setDraggingElement] = useState<CanvasElement | null>(
    null
  );
  const [editingTextElement, setEditingTextElement] =
    useState<CanvasElement | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      const context = canvasRef.current.getContext("2d");
      if (context) {
        setCtx(context);
        loadImage(context);
      }
    }
  }, [imageUrl]);

  const loadImage = (context: CanvasRenderingContext2D) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = imageUrl;
    img.onload = () => {
      context.clearRect(0, 0, 600, 400);
      context.drawImage(img, 0, 0, 600, 400);
      setCanvasElements((prevElements) => [
        ...prevElements.filter((el) => el.type !== "image"),
        {
          id: Date.now(),
          type: "image",
          x: 0,
          y: 0,
          width: 600,
          height: 400,
        },
      ]);
    };
  };

  const drawCanvasElements = () => {
    if (!ctx) return;

    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    canvasElements.forEach((element) => {
      if (element.type === "image" && element.width && element.height) {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.src = imageUrl;
        ctx.drawImage(img, element.x, element.y, element.width, element.height);
      }
    });

    canvasElements.forEach((element) => {
      if (element.type === "rectangle") {
        ctx.fillStyle = element.color || "#FF5733";
        ctx.fillRect(
          element.x,
          element.y,
          element.width || 100,
          element.height || 50
        );
      } else if (element.type === "circle") {
        ctx.beginPath();
        ctx.arc(element.x, element.y, element.radius || 50, 0, Math.PI * 2);
        ctx.fillStyle = element.color || "#3498DB";
        ctx.fill();
      } else if (element.type === "triangle") {
        ctx.beginPath();
        ctx.moveTo(element.x, element.y);
        ctx.lineTo(
          element.x - (element.width || 50),
          element.y + (element.height || 100)
        );
        ctx.lineTo(
          element.x + (element.width || 50),
          element.y + (element.height || 100)
        );
        ctx.closePath();
        ctx.fillStyle = element.color || "#F4D03F";
        ctx.fill();
      }
    });

    canvasElements.forEach((element) => {
      if (element.type === "text") {
        ctx.fillStyle = element.color || "#000";
        ctx.font = "20px Arial";
        ctx.fillText(element.text || "", element.x, element.y);
      }
    });
  };

  const addElement = (type: "text" | "rectangle" | "circle" | "triangle") => {
    const newElement: CanvasElement = {
      id: Date.now(),
      type,
      x: 150,
      y: 150,
      text: type === "text" ? "Enter Text" : undefined,
      width: type === "rectangle" ? 100 : undefined,
      height: type === "rectangle" ? 50 : undefined,
      radius: type === "circle" ? 50 : undefined,
      color: type === "text" ? "#000" : "#FF5733",
    };

    setCanvasElements((prevElements) => [...prevElements, newElement]);
    drawCanvasElements();
  };

  const handleMouseDown = (
    e: React.MouseEvent<HTMLCanvasElement, MouseEvent>
  ) => {
    const mouseX = e.nativeEvent.offsetX;
    const mouseY = e.nativeEvent.offsetY;

    const clickedElement = canvasElements.find(
      (element) =>
        mouseX >= element.x &&
        mouseX <=
          element.x +
            (element.width && !isNaN(element.width)
              ? element.width
              : element.radius && !isNaN(element.radius)
              ? element.radius * 2
              : 50) &&
        mouseY >= element.y &&
        mouseY <=
          element.y +
            (element.height && !isNaN(element.height)
              ? element.height
              : element.radius && !isNaN(element.radius)
              ? element.radius * 2
              : 50)
    );

    if (clickedElement) {
      if (clickedElement.type === "text") {
        setEditingTextElement(clickedElement);
      } else {
        setDraggingElement({
          ...clickedElement,
          offsetX: mouseX - clickedElement.x,
          offsetY: mouseY - clickedElement.y,
          isDragging: true,
        });
      }
    }
  };

  const handleMouseMove = (
    e: React.MouseEvent<HTMLCanvasElement, MouseEvent>
  ) => {
    if (!draggingElement || !ctx) return;

    const mouseX = e.nativeEvent.offsetX;
    const mouseY = e.nativeEvent.offsetY;

    const updatedElements = canvasElements.map((element) =>
      element.id === draggingElement.id
        ? {
            ...element,
            x: mouseX - draggingElement.offsetX!,
            y: mouseY - draggingElement.offsetY!,
          }
        : element
    );

    setCanvasElements(updatedElements);
    drawCanvasElements();
  };

  const handleMouseUp = () => {
    if (draggingElement) {
      setDraggingElement(null);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (editingTextElement) {
      const updatedElements = canvasElements.map((element) =>
        element.id === editingTextElement.id
          ? { ...element, text: e.target.value }
          : element
      );
      setCanvasElements(updatedElements);
      drawCanvasElements();
    }
  };

  const downloadCanvas = () => {
    if (!canvasRef.current) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = imageUrl;
    img.onload = () => {
      if (ctx) {
        ctx.clearRect(0, 0, 600, 400);
        ctx.drawImage(img, 0, 0, 600, 400);
        drawCanvasElements();

        const link = document.createElement("a");
        link.download = "modified-image.png";
        link.href = canvasRef.current.toDataURL("image/png");
        link.click();
      }
    };
  };

  useEffect(() => {
    drawCanvasElements();
  }, [canvasElements]);

  return (
    <div className="container mt-4">
      <h4>Edit Image</h4>
      <div
        className="text-center"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        <canvas
          ref={canvasRef}
          width={500}
          height={400}
          className="border border-secondary"
        />
      </div>

      <div className="mt-3 text-center">
        <button
          className="btn btn-info me-2"
          onClick={() => addElement("text")}
        >
          Add Text
        </button>
        <button
          className="btn btn-warning me-2"
          onClick={() => addElement("rectangle")}
        >
          Add Rectangle
        </button>
        <button
          className="btn btn-warning me-2"
          onClick={() => addElement("circle")}
        >
          Add Circle
        </button>
        <button
          className="btn btn-warning me-2"
          onClick={() => addElement("triangle")}
        >
          Add Triangle
        </button>
        <button className="btn btn-success me-2" onClick={downloadCanvas}>
          Download Image
        </button>
      </div>
      {editingTextElement && (
        <div className="mt-3 text-center">
          <input
            type="text"
            value={editingTextElement.text || ""}
            onChange={handleTextChange}
          />
        </div>
      )}

      <div className="mt-4">
        <h5>Canvas Layers (Debug Info):</h5>
        <pre>{JSON.stringify(canvasElements, null, 2)}</pre>
      </div>
    </div>
  );
};

export default AddCaptionPage;
