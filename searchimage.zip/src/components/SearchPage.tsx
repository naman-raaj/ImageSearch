import React, { useState } from "react";
import { fetchImages } from "../apiService/api";

interface SearchPageProps {
  onSelectImage: (url: string) => void;
}

const SearchPage: React.FC<SearchPageProps> = ({ onSelectImage }) => {
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [images, setImages] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!name || !email || !searchTerm) {
      setValidationError("All fields are required.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setValidationError("Please enter a valid email address.");
      return;
    }

    setValidationError(null);

    try {
      const results = await fetchImages(searchTerm);
      setImages(results);
      setError(null);
    } catch (error: any) {
      setError(error.message);
    }
  };

  return (
    <div className="container mt-4">
      <h4>Search Images</h4>
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="border p-4 rounded">
            <div className="mb-3">
              <input
                type="text"
                required
                className="form-control"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="col-mb-3 mt-2">
              <input
                type="email"
                required
                className="form-control"
                placeholder="Enter your email"
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="col-mb-3 mt-2">
              <input
                type="text"
                required
                className="form-control"
                placeholder="Search for an image"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <div>
                <button
                  className="btn btn-primary w-100 mt-2"
                  onClick={handleSearch}
                >
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>

        {validationError && (
          <div className="alert alert-danger mt-3">{validationError}</div>
        )}
        {error && <div className="alert alert-danger mt-3">{error}</div>}

        <div className="row mt-4">
          {images.map((image, index) => (
            <div className="col-md-3 mb-3" key={index}>
              <img
                src={image.webformatURL}
                alt={image.tags}
                className="img-thumbnail"
              />
              <button
                className="btn btn-success btn-sm mt-2 w-100"
                onClick={() => onSelectImage(image.webformatURL)}
              >
                Add Captions
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchPage;
