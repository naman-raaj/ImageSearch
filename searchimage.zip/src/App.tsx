import React, { useState } from "react";
import SearchPage from "./components/SearchPage";
import AddCaptionPage from "./components/AddCaptionPage";

const App: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <div className="container mt-5">
      {!selectedImage ? (
        <SearchPage onSelectImage={(url) => setSelectedImage(url)} />
      ) : (
        <AddCaptionPage imageUrl={selectedImage} />
      )}
    </div>
  );
};

export default App;
