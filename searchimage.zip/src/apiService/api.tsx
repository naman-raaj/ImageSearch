const API_KEY = "49544934-e53afc4fc078e17a442913c90";
const API_URL = "https://pixabay.com/api/";

export const fetchImages = async (query: string) => {
  try {
    const response = await fetch(
      `${API_URL}?key=${API_KEY}&q=${encodeURIComponent(
        query
      )}&image_type=photo`
    );
    if (!response.ok) {
      throw new Error("Error fetching images. Please try again.");
    }
    const data = await response.json();
    if (data.hits.length === 0) {
      throw new Error("No images found for the search term.");
    }
    return data.hits;
  } catch (error: any) {
    throw new Error(error.message);
  }
};
